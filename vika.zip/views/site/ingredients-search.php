<!-- ================= MAIN CONTENT ================= -->
<main class="w-full pt-28 pb-16 flex-1" id="inventory-section">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col gap-8">
        
        <!-- Intro Header Banner -->
        <div class="relative bg-[#FAF4EB] border-2 border-[#D4B996] p-6 sm:p-8 shadow-scrapbook rounded-3xl">
            <div class="washi-tape washi-sage -top-3 left-10 w-32 h-6 -rotate-2"></div>
            <div class="washi-tape washi-honey -top-2 right-12 w-24 h-5 rotate-3"></div>

            <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
                <div class="flex flex-col gap-2 max-w-2xl">
                    <div class="inline-flex items-center gap-1.5 px-3 py-1 bg-[#EDF4EF] text-sage font-mono text-xs uppercase tracking-wider font-bold self-start border border-sage/20 rounded-md">
                        <span class="material-symbols-outlined text-sm">kitchen</span>
                        Экономная кулинария
                    </div>
                    <h1 class="text-3xl lg:text-4xl font-bold text-warm-ink font-serif">Что в холодильнике?</h1>
                    <p class="font-sans text-xs sm:text-sm text-warm-muted leading-relaxed">
                        Отметьте продукты, которые есть у вас дома, и наш архив мгновенно подберет подходящие домашние рецепты без похода в магазин.
                    </p>
                </div>

                <!-- Selected Counter Badge -->
                <div class="bg-white px-5 py-4 border border-[#D4B996] rounded-2xl shadow-xs flex items-center gap-3 shrink-0">
                    <div class="w-10 h-10 bg-terracotta/10 text-terracotta flex items-center justify-center rounded-xl">
                        <span class="material-symbols-outlined text-2xl">checklist</span>
                    </div>
                    <div>
                        <span class="block font-mono text-[11px] text-warm-muted uppercase tracking-wider">Выбрано продуктов</span>
                        <span class="font-mono text-lg font-bold text-terracotta" id="selectedCounterBadge">6 позиций</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Inventory List Box -->
        <div class="relative bg-white border border-[#D4B996] shadow-scrapbook p-6 sm:p-8 rounded-3xl">
            
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dashed border-[#D4B996] pb-4 mb-6">
                <div>
                    <span class="font-mono text-[11px] text-warm-muted uppercase tracking-widest">Кладовая</span>
                    <h2 class="text-2xl text-warm-ink font-serif font-bold">Выберите имеющиеся ингредиенты</h2>
                </div>
                
                <button class="px-4 py-2 bg-white hover:bg-paper text-terracotta border border-[#D4B996] font-sans text-xs font-bold transition-colors rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-auto" onclick="clearAllSelections()" type="button">
                    <span class="material-symbols-outlined text-base">restart_alt</span>
                    <span>Очистить выбор</span>
                </button>
            </div>

            <!-- Add Custom Ingredient Form -->
            <form class="mb-6 relative flex items-center" id="customIngredientForm" onsubmit="addCustomIngredient(event)">
                <div class="w-full flex items-stretch border border-[#D4B996] bg-[#FFF9F4] shadow-xs focus-within:border-terracotta rounded-xl overflow-hidden">
                    <input autocomplete="off" class="w-full bg-transparent font-sans text-xs sm:text-sm text-warm-ink placeholder-[#8a726a] px-4 py-3 border-0 focus:ring-0 outline-none" id="customIngredientInput" placeholder="Добавить свой продукт (например, Розмарин)..." type="text">
                    <button aria-label="Добавить" class="shrink-0 px-5 bg-terracotta hover:bg-terracotta-hover text-white font-sans text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer" type="submit">
                        <span class="material-symbols-outlined text-base">add</span>
                        <span>Добавить</span>
                    </button>
                </div>
            </form>

            <!-- Ingredients Grid -->
           <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8" id="ingredientsGrid">
                
                <!-- Item 1 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-[#FFF9F4] hover:bg-[#FAF4EB] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Томаты спелые" data-checked="true">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input checked class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Томаты спелые</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 2 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-[#FFF9F4] hover:bg-[#FAF4EB] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Картофель" data-checked="true">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input checked class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Картофель</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 3 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-[#FFF9F4] hover:bg-[#FAF4EB] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Лук репчатый" data-checked="true">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input checked class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Лук репчатый</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 4 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Чеснок" data-checked="false">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Чеснок</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 5 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-[#FFF9F4] hover:bg-[#FAF4EB] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Яйца куриные" data-checked="true">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input checked class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Яйца куриные C0</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 6 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-[#FFF9F4] hover:bg-[#FAF4EB] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Сливочное масло" data-checked="true">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input checked class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Сливочное масло 82%</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 7 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Сыр пармезан" data-checked="false">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Сыр Пармезан</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 8 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Мука пшеничная" data-checked="false">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Мука пшеничная</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 9 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Спагетти" data-checked="false">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Спагетти твердых сортов</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

                <!-- Item 10 -->
                <div class="ingredient-item flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] border border-[#D4B996]/50 transition-colors rounded-xl" data-name="Бекон" data-checked="false">
                    <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input class="custom-checkbox" type="checkbox" onchange="updateSearch()">
                        <span class="font-sans text-sm font-medium text-warm-ink truncate">Бекон сырокопченый</span>
                    </label>
                    <button type="button" onclick="promptDelete(this)" class="ml-2 text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить продукт">
                        <span class="material-symbols-outlined text-base leading-none">close</span>
                    </button>
                </div>

            </div>

        </div>

        <!-- Recipe Results Showcase Section -->
        <div class="flex flex-col gap-6" id="resultsSection">
            <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-dashed border-[#D4B996]">
                <div>
                    <span class="font-mono text-[11px] text-warm-muted uppercase tracking-widest">Результаты подбора</span>
                    <h2 class="text-2xl sm:text-3xl font-bold text-warm-ink font-serif" id="resultsTitle">Найдено 4 рецепта под ваши продукты</h2>
                </div>
                
                <!-- Sort / Filter Ribbon Controls -->
                <div class="flex items-center gap-2">
                    <span class="font-mono text-xs text-warm-muted hidden sm:inline">Сортировка:</span>
                    <button class="px-3.5 py-2 bg-terracotta text-white font-sans text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer rounded-xl" id="sortByMatch" onclick="setSortMode('match')" type="button">
                        <span class="material-symbols-outlined text-sm">verified</span>
                        <span>По совпадению</span>
                    </button>
                    <button class="px-3.5 py-2 bg-white hover:bg-paper text-warm-muted hover:text-warm-ink border border-[#D4B996] font-sans text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer rounded-xl" id="sortByTime" onclick="setSortMode('time')" type="button">
                        <span class="material-symbols-outlined text-sm">schedule</span>
                        <span>По времени</span>
                    </button>
                </div>
            </div>

            <!-- Recipe Cards Container (Dynamic) -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="recipeCardsContainer">
                <!-- Dynamically populated by JS -->
            </div>

            <!-- Bottom Return to Top Button -->
            <div class="mt-8 flex justify-center">
                <button class="px-6 py-3 bg-[#FAF4EB] hover:bg-paper border border-[#D4B996] text-warm-ink font-sans text-xs font-bold transition-colors rounded-xl shadow-xs flex items-center gap-2 cursor-pointer" onclick="scrollToTop()" type="button">
                    <span class="material-symbols-outlined text-base">arrow_upward</span>
                    <span>Вверх к списку продуктов</span>
                </button>
            </div>
        </div>

    </div>
</main>

<!-- Delete Confirmation Modal -->
<div aria-labelledby="modal-title" aria-modal="true" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-warm-ink/60 backdrop-blur-xs transition-opacity duration-200 opacity-0 pointer-events-none" id="delete-modal" role="dialog">
    <div class="relative w-full max-w-md bg-white rounded-3xl shadow-scrapbook border-2 border-dashed border-[#D4B996] p-6 sm:p-7 transform transition-transform duration-200 scale-95" id="delete-modal-panel">
        <div class="washi-tape washi-sage -top-3.5 left-1/2 -translate-x-1/2 w-28 h-6 -rotate-1 pointer-events-none"></div>
        
        <div class="flex items-start justify-between mb-4 pt-1">
            <div class="flex items-center gap-2">
                <span class="material-symbols-outlined text-terracotta text-lg">bookmark</span>
                <span class="font-mono text-xs font-bold text-terracotta uppercase tracking-wider">Удаление продукта</span>
            </div>
            <button aria-label="Закрыть" class="text-warm-muted hover:text-warm-ink transition-colors p-1 cursor-pointer" onclick="closeDeleteModal()" type="button">
                <span class="material-symbols-outlined text-lg leading-none">close</span>
            </button>
        </div>

        <h3 class="text-2xl font-serif font-bold text-warm-ink mb-3" id="modal-title">
            Удалить продукт из кладовой?
        </h3>

        <div class="bg-[#FFF9F4] border-l-4 border-l-terracotta border border-[#D4B996] p-3.5 mb-4 rounded-xl shadow-xs">
            <span class="block font-mono text-[10px] text-warm-muted uppercase tracking-wider mb-1">Продукт:</span>
            <p class="font-sans text-sm font-bold text-warm-ink" id="modal-item-name">«Томаты спелые»</p>
        </div>

        <p class="font-sans text-xs text-warm-muted leading-relaxed mb-6">
            Вы сможете добавить его снова в любой момент с помощью формы выше.
        </p>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-dashed border-[#D4B996]">
            <button class="px-4 py-2 border border-[#D4B996] bg-white hover:bg-paper text-warm-ink font-sans text-xs font-bold transition-colors rounded-xl cursor-pointer" onclick="closeDeleteModal()" type="button">
                Отмена
            </button>
            <button class="px-5 py-2 bg-terracotta hover:bg-terracotta-hover text-white font-sans text-xs font-bold transition-colors rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer" onclick="confirmDelete()" type="button">
                <span class="material-symbols-outlined text-sm">delete</span>
                <span>Удалить</span>
            </button>
        </div>
    </div>
</div>

<!-- Toast Notification Box -->
<div class="fixed bottom-6 right-6 z-50 bg-[#FAF4EB] border-2 border-terracotta shadow-scrapbook p-4 max-w-sm hidden rounded-2xl" id="auth-toast">
    <div class="flex items-start gap-3">
        <span class="material-symbols-outlined text-terracotta text-2xl shrink-0">verified</span>
        <div class="flex flex-col">
            <span class="font-serif font-bold text-base text-warm-ink" id="toast-title">Folk Menu</span>
            <span class="font-sans text-xs text-warm-muted mt-0.5" id="toast-message">Уведомление</span>
        </div>
    </div>
</div>