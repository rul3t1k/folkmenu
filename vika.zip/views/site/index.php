<?php
use yii\helpers\Url;
?><!-- ================= MAIN CONTENT ================= -->
<main class="w-full pt-20 flex-1">
    
    <!-- Top Archival Welcome Banner -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-2">
        <div class="relative bg-paper border border-craft-border rounded-2xl p-5 md:p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-5 overflow-hidden">
            <div class="flex items-center gap-4 pt-1 md:pt-0">
                <div class="w-13 h-13 rounded-2xl bg-white border border-craft-border flex items-center justify-center text-terracotta shrink-0 shadow-sm">
                    <span class="material-symbols-outlined text-2xl">auto_stories</span>
                </div>
                <div>
                    <div class="flex items-center gap-2 flex-wrap">
                        <h2 class="font-serif text-2xl sm:text-3xl font-bold text-warm-ink tracking-tight">Кулинарный архив поколений</h2>
                        <span class="text-terracotta text-sm">✦</span>
                        <span class="font-hand text-lg text-terracotta font-bold hidden sm:inline-block">100 лет семейных традиций</span>
                    </div>
                    <p class="text-sm text-warm-muted mt-1 max-w-2xl">
                        Бережно собранные, береженные и адаптированные рецепты домашней кухни: живые рукописные заметки, точные граммовки и тепло родного очага.
                    </p>
                </div>
            </div>
            <div class="flex items-center gap-3.5 bg-white/90 border border-craft-border px-4 py-2.5 rounded-xl shadow-xs shrink-0 self-stretch md:self-auto justify-between md:justify-start">
                <div class="w-10 h-10 rounded-lg bg-sage-light text-sage flex items-center justify-center shrink-0">
                    <span class="material-symbols-outlined text-xl">inventory_2</span>
                </div>
                <div class="text-left">
                    <div class="text-xs font-bold text-warm-ink uppercase tracking-wider">Том VII • Осенняя коллекция</div>
                    <div class="text-xs text-warm-muted mt-0.5">315 проверенных блюд с фото</div>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= HERO SECTION: РЕЦЕПТ ДНЯ ================= -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7">
        <div class="relative bg-surface border-2 border-craft-border rounded-3xl shadow-scrapbook overflow-hidden p-6 sm:p-8 lg:p-10">
            <div class="washi-tape washi-terracotta top-7 sm:top-8 left-8 sm:left-12 px-8 py-3 flex items-center justify-center text-base sm:text-lg text-white font-bold tracking-widest uppercase shadow-md z-20 rotate-0">★ РЕЦЕПТ ДНЯ ★</div>
            
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center pt-4">
                <!-- LEFT: Vintage Polaroid Photo Framing -->
                <div class="lg:col-span-7">
                    <div class="relative bg-white p-4 sm:p-5 rounded-2xl border border-craft-border shadow-polaroid -rotate-1 hover:rotate-0 transition-transform duration-500">
                        <div class="washi-tape -top-3 left-6 w-24 h-6 rounded-xs -rotate-4 washi-sage"></div>
                        <div class="washi-tape washi-honey -bottom-3 right-8 w-28 h-6 rounded-xs rotate-2"></div>
                        
                        <div class="absolute top-7 left-7 z-20 flex flex-wrap gap-2">
                            <span class="px-3 py-1 bg-terracotta text-white text-xs font-bold rounded-md shadow-sm flex items-center gap-1">
                                <span class="material-symbols-outlined text-sm leading-none">local_fire_department</span> Сезонный хит
                            </span>
                        </div>
                        
                        <div class="force-round absolute bottom-16 right-7 z-20 hidden sm:flex w-20 h-20 items-center justify-center text-center rotate-12 pointer-events-none rounded-full border-2 border-dashed border-[#d96b27]/70 bg-[#fef9c3]/90 shadow-sm p-1">
                            <div class="force-round w-full h-full rounded-full border border-[#d96b27]/60 flex items-center justify-center bg-[#fef3c7]/60">
                                <span class="font-serif text-[8px] font-bold text-[#b45309] uppercase leading-tight tracking-wider">ПРОВЕРЕНО<br>ГОДАМИ<br>★★★★★</span>
                            </div>
                        </div>
                        
                        <div class="relative w-full h-80 sm:h-96 md:h-[420px] rounded-xl overflow-hidden bg-craft-subtle border border-craft-border">
                            <img alt="Домашний яблочный пирог с карамелью и корицей" class="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700" src="<?= Url::to(['/images/главный пирог.jpg']) ?>">
                            <div class="absolute inset-0 bg-gradient-to-t from-warm-ink/85 via-warm-ink/25 to-transparent"></div>
                            <div class="absolute bottom-5 left-5 right-5 text-white">
                                <div class="text-xs uppercase tracking-widest text-honey-warm font-semibold mb-1.5 flex items-center gap-1.5">
                                    <span class="material-symbols-outlined text-sm">auto_stories</span>
                                    <span>Семейная тетрадь • Вологда</span>
                                </div>
                                <h1 class="font-serif text-2xl sm:text-3xl md:text-4xl font-bold leading-snug drop-shadow-md">
                                    Домашний яблочный пирог с карамелью и корицей
                                </h1>
                            </div>
                        </div>

                        <div class="pt-3.5 px-1 flex flex-wrap items-center justify-between text-xs text-warm-muted gap-2">
                            <span class="font-serif italic text-sm sm:text-base font-semibold text-vintage-brown">
                                «Запись из кулинарной тетради бабушки Варвары»
                            </span>
                            <!-- <div class="flex items-center gap-1 text-terracotta bg-[#FFF8F0] px-3 py-1 rounded-lg border border-craft-border shadow-xs">
                                <span class="material-symbols-outlined text-base fill-1">star</span>
                                <span class="material-symbols-outlined text-base fill-1">star</span>
                                <span class="material-symbols-outlined text-base fill-1">star</span>
                                <span class="material-symbols-outlined text-base fill-1">star</span>
                                <span class="material-symbols-outlined text-base fill-1">star</span>
                                <span class="font-bold ml-1 text-warm-ink">5.0</span>
                                <span class="text-warm-muted">(142 отзыва)</span>
                            </div> -->
                        </div>
                    </div>
                </div>

                <!-- RIGHT: Journal Recipe Page -->
                <div class="lg:col-span-5 flex flex-col gap-4">
                    <div class="flex items-center gap-2">
                        <span class="px-2.5 py-1 bg-sage-light text-sage border border-sage/25 text-xs font-bold rounded-md uppercase tracking-wider">
                            Осенний сбор
                        </span>
                        <span class="text-xs text-warm-muted font-medium">Карточка рецепта № 108</span>
                    </div>
                    
                    <blockquote class="font-serif text-2xl md:text-3xl text-warm-ink leading-snug italic border-l-4 border-terracotta pl-4 my-1 font-bold">
                        «Пирог получается пышным, сладким и хранит тепло до самого вечернего чаепития»
                    </blockquote>

                    <!-- Quick Metrics Stamp Card -->
                    <div class="grid grid-cols-3 gap-2 py-3 px-3.5 bg-paper border border-craft-border rounded-xl shadow-xs">
                        <div class="flex flex-col items-center text-center">
                            <span class="material-symbols-outlined text-terracotta text-2xl mb-1">timer</span>
                            <span class="font-bold text-base text-warm-ink">55 мин</span>
                            <span class="text-[11px] text-warm-muted">Время в печи</span>
                        </div>
                        <div class="flex flex-col items-center text-center border-x border-craft-border">
                            <span class="material-symbols-outlined text-sage text-2xl mb-1">tune</span>
                            <span class="font-bold text-base text-warm-ink">Средняя</span>
                            <span class="text-[11px] text-warm-muted">Сложность</span>
                        </div>
                        <div class="flex flex-col items-center text-center">
                            <span class="material-symbols-outlined text-honey text-2xl mb-1">local_fire_department</span>
                            <span class="font-bold text-base text-warm-ink">290 ккал</span>
                            <span class="text-[11px] text-warm-muted">Порция (150 г)</span>
                        </div>
                    </div>

                    <!-- Pinned Sticky Note -->
                    <div class="p-4 bg-honey-light border-2 border-dashed border-honey-warm/60 rounded-xl relative shadow-xs">
                        <div class="washi-tape washi-honey -top-2.5 right-8 w-18 h-4 rounded-xs rotate-1"></div>
                        <div class="flex items-start gap-2.5">
                            <span class="material-symbols-outlined text-terracotta text-xl shrink-0 mt-0.5">lightbulb</span>
                            <div>
                                <h4 class="text-xs font-bold uppercase tracking-wider text-terracotta flex items-center gap-1">
                                    <span class="material-symbols-outlined text-sm">draw</span> Секрет хозяйки:
                                </h4>
                                <p class="text-sm text-warm-ink italic mt-1 leading-relaxed">
                                    «Добавьте щепотку мускатного ореха в растопленное сливочное масло, а дольки яблок слегка сбрызните лимонным соком перед выпеканием — тогда аромат раскроется ярче».
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Ingredients Memo Box -->
                    <div class="text-sm bg-white p-3.5 rounded-xl border border-craft-border shadow-xs">
                        <span class="text-xs uppercase font-bold text-warm-muted tracking-wider block mb-1">Главные ингредиенты:</span>
                        <p class="text-warm-ink leading-relaxed font-medium">
                            Яблоки антоновка (5 шт.), сливочное масло 82%, цейлонская корица, тростниковый сахар, лепестки миндаля.
                        </p>
                    </div>

                    <!-- Action CTA Buttons -->
                    <div class="flex items-center gap-3 pt-1">
                        <a class="flex-1 py-3 px-6 bg-terracotta hover:bg-terracotta-hover text-white rounded-xl font-bold text-sm text-center shadow-md border border-terracotta/40 transition-all active:scale-[0.98] flex items-center justify-center gap-2 group" href="<?= Url::to(['recipe']) ?>">
                            <span class="material-symbols-outlined text-lg leading-none group-hover:rotate-12 transition-transform">menu_book</span>
                            <span>Смотреть рецепт</span>
                        </a>
                        <button class="p-3 bg-white hover:bg-paper text-terracotta border border-craft-border rounded-xl transition-colors shadow-xs active:scale-95" title="Сохранить в избранное" type="button">
                            <span class="material-symbols-outlined text-xl">bookmark_add</span>
                        </button>
                        <button class="p-3 bg-white hover:bg-paper text-sage border border-craft-border rounded-xl transition-colors shadow-xs active:scale-95" title="Добавить ингредиенты в список" type="button">
                            <span class="material-symbols-outlined text-xl">add_shopping_cart</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= CATEGORY GRID: 6 CRAFT CARDS ================= -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
                <div class="flex items-center gap-2 text-xs font-bold text-terracotta uppercase tracking-wider">
                    <span class="w-6 h-0.5 bg-terracotta"></span> Оглавление кулинарной книги
                </div>
                <h2 class="font-serif text-3xl md:text-4xl font-bold text-warm-ink mt-1">Категории блюд</h2>
            </div>
            <p class="text-sm text-warm-muted max-w-md">
                Удобный рубрикатор: от наваристых обеденных супов до праздничных тортов и домашних зимних заготовок.
            </p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
            <!-- Category 1 -->
            <a class="group relative bg-white border border-craft-border rounded-2xl p-6 shadow-xs hover:shadow-card-lift hover:border-sage transition-all duration-300 flex flex-col justify-between" href="<?= Url::to(['recipe']) ?>">
                <div class="washi-tape washi-sage -top-3 left-8 w-24 h-6 rounded-xs -rotate-2"></div>
                <div>
                    <div class="flex items-center justify-between mb-4 pt-1">
                        <div class="w-12 h-12 rounded-xl bg-sage-light text-sage flex items-center justify-center group-hover:scale-110 transition-transform">
                            <span class="material-symbols-outlined text-2xl">soup_kitchen</span>
                        </div>
                        <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-paper text-warm-muted border border-craft-border">42 рецепта</span>
                    </div>
                    <h3 class="font-serif text-2xl font-bold text-warm-ink group-hover:text-sage transition-colors">Супы и бульоны</h3>
                    <p class="text-sm text-warm-muted mt-2 leading-relaxed">Наваристый борщ, грибная юшка с белыми грибами, сырные крем-супы и прозрачная уха.</p>
                </div>
                <div class="pt-5 mt-3 border-t border-craft-subtle flex items-center text-xs font-bold text-sage group-hover:translate-x-1 transition-transform">
                    <span>Смотреть категорию</span>
                    <span class="material-symbols-outlined text-sm ml-1">arrow_forward</span>
                </div>
            </a>

            <!-- Category 2 -->
            <a class="group relative bg-white border border-craft-border rounded-2xl p-6 shadow-xs hover:shadow-card-lift hover:border-terracotta transition-all duration-300 flex flex-col justify-between" href="<?= Url::to(['recipe']) ?>">
                <div class="washi-tape washi-terracotta -top-3 left-8 w-24 h-6 rounded-xs rotate-1"></div>
                <div>
                    <div class="flex items-center justify-between mb-4 pt-1">
                        <div class="w-12 h-12 rounded-xl bg-terracotta-light text-terracotta flex items-center justify-center group-hover:scale-110 transition-transform">
                            <span class="material-symbols-outlined text-2xl">bakery_dining</span>
                        </div>
                        <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-paper text-warm-muted border border-craft-border">68 рецептов</span>
                    </div>
                    <h3 class="font-serif text-2xl font-bold text-warm-ink group-hover:text-terracotta transition-colors">Домашняя выпечка</h3>
                    <p class="text-sm text-warm-muted mt-2 leading-relaxed">Пышные пироги с капустой и рыбой, расстегаи, хрустящий багет и сдобные булочки с маком.</p>
                </div>
                <div class="pt-5 mt-3 border-t border-craft-subtle flex items-center text-xs font-bold text-terracotta group-hover:translate-x-1 transition-transform">
                    <span>Смотреть категорию</span>
                    <span class="material-symbols-outlined text-sm ml-1">arrow_forward</span>
                </div>
            </a>

            <!-- Category 3 -->
            <a class="group relative bg-white border border-craft-border rounded-2xl p-6 shadow-xs hover:shadow-card-lift hover:border-honey transition-all duration-300 flex flex-col justify-between" href="<?= Url::to(['recipe']) ?>">
                <div class="washi-tape washi-honey -top-3 left-10 w-24 h-6 rounded-xs -rotate-1"></div>
                <div>
                    <div class="flex items-center justify-between mb-4 pt-1">
                        <div class="w-12 h-12 rounded-xl bg-honey-light text-honey flex items-center justify-center group-hover:scale-110 transition-transform">
                            <span class="material-symbols-outlined text-2xl">cake</span>
                        </div>
                        <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-paper text-warm-muted border border-craft-border">55 рецептов</span>
                    </div>
                    <h3 class="font-serif text-2xl font-bold text-warm-ink group-hover:text-honey transition-colors">Десерты и сладости</h3>
                    <p class="text-sm text-warm-muted mt-2 leading-relaxed">Медовые коврижки, яблочная пастила, легкие меренги и шоколадные трюфели ручной работы.</p>
                </div>
                <div class="pt-5 mt-3 border-t border-craft-subtle flex items-center text-xs font-bold text-honey group-hover:translate-x-1 transition-transform">
                    <span>Смотреть категорию</span>
                    <span class="material-symbols-outlined text-sm ml-1">arrow_forward</span>
                </div>
            </a>

            <!-- Category 4 -->
            <a class="group relative bg-white border border-craft-border rounded-2xl p-6 shadow-xs hover:shadow-card-lift hover:border-rose transition-all duration-300 flex flex-col justify-between" href="<?= Url::to(['recipe']) ?>">
                <div class="washi-tape washi-rose -top-3 right-10 w-24 h-6 rounded-xs rotate-2"></div>
                <div>
                    <div class="flex items-center justify-between mb-4 pt-1">
                        <div class="w-12 h-12 rounded-xl bg-rose-light text-rose flex items-center justify-center group-hover:scale-110 transition-transform">
                            <span class="material-symbols-outlined text-2xl">skillet</span>
                        </div>
                        <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-paper text-warm-muted border border-craft-border">89 рецептов</span>
                    </div>
                    <h3 class="font-serif text-2xl font-bold text-warm-ink group-hover:text-rose transition-colors">Основные блюда</h3>
                    <p class="text-sm text-warm-muted mt-2 leading-relaxed">Жаркое в глиняных горшочках, утка с брусничным соусом, томленые ребра и сочное филе.</p>
                </div>
                <div class="pt-5 mt-3 border-t border-craft-subtle flex items-center text-xs font-bold text-rose group-hover:translate-x-1 transition-transform">
                    <span>Смотреть категорию</span>
                    <span class="material-symbols-outlined text-sm ml-1">arrow_forward</span>
                </div>
            </a>

            <!-- Category 5 -->
            <a class="group relative bg-white border border-craft-border rounded-2xl p-6 shadow-xs hover:shadow-card-lift hover:border-sage transition-all duration-300 flex flex-col justify-between" href="<?= Url::to(['recipe']) ?>">
                <div class="washi-tape washi-sage -top-3 left-8 w-24 h-6 rounded-xs -rotate-2"></div>
                <div>
                    <div class="flex items-center justify-between mb-4 pt-1">
                        <div class="w-12 h-12 rounded-xl bg-sage-light text-sage flex items-center justify-center group-hover:scale-110 transition-transform">
                            <span class="material-symbols-outlined text-2xl">nutrition</span>
                        </div>
                        <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-paper text-warm-muted border border-craft-border">34 рецепта</span>
                    </div>
                    <h3 class="font-serif text-2xl font-bold text-warm-ink group-hover:text-sage transition-colors">Заготовки на зиму</h3>
                    <p class="text-sm text-warm-muted mt-2 leading-relaxed">Моченые яблоки с травами, хрустящие грузди с чесноком, варенье из сливы и шишек.</p>
                </div>
                <div class="pt-5 mt-3 border-t border-craft-subtle flex items-center text-xs font-bold text-sage group-hover:translate-x-1 transition-transform">
                    <span>Смотреть категорию</span>
                    <span class="material-symbols-outlined text-sm ml-1">arrow_forward</span>
                </div>
            </a>

            <!-- Category 6 -->
            <a class="group relative bg-white border border-craft-border rounded-2xl p-6 shadow-xs hover:shadow-card-lift hover:border-honey transition-all duration-300 flex flex-col justify-between" href="<?= Url::to(['recipe']) ?>">
                <div class="washi-tape washi-honey -top-3 right-8 w-24 h-6 rounded-xs -rotate-2"></div>
                <div>
                    <div class="flex items-center justify-between mb-4 pt-1">
                        <div class="w-12 h-12 rounded-xl bg-[#FFF8EE] text-honey flex items-center justify-center group-hover:scale-110 transition-transform">
                            <span class="material-symbols-outlined text-2xl">egg_alt</span>
                        </div>
                        <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-paper text-warm-muted border border-craft-border">27 рецептов</span>
                    </div>
                    <h3 class="font-serif text-2xl font-bold text-warm-ink group-hover:text-honey transition-colors">Завтраки</h3>
                    <p class="text-sm text-warm-muted mt-2 leading-relaxed">Пышные творожные сырники, гречневые блины, каши на топленом молоке и воздушные омлеты.</p>
                </div>
                <div class="pt-5 mt-3 border-t border-craft-subtle flex items-center text-xs font-bold text-honey group-hover:translate-x-1 transition-transform">
                    <span>Смотреть категорию</span>
                    <span class="material-symbols-outlined text-sm ml-1">arrow_forward</span>
                </div>
            </a>
        </div>
    </section>

    <!-- ================= POPULAR RECIPES SECTION ================= -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div class="flex flex-col md:flex-row md:items-center justify-between pb-6 gap-4">
            <div>
                <div class="flex items-center gap-1.5 text-xs font-bold text-terracotta uppercase tracking-wider">
                    <span class="material-symbols-outlined text-base">workspace_premium</span> Проверено годами
                </div>
                <h2 class="font-serif text-3xl md:text-4xl font-bold text-warm-ink mt-1">Популярные рецепты</h2>
            </div>
            <div class="flex flex-wrap gap-2">
                <button class="px-3.5 py-1.5 rounded-lg bg-terracotta text-white text-xs font-bold shadow-xs" type="button">Все рецепты</button>
                <button class="px-3.5 py-1.5 rounded-lg bg-white hover:bg-paper text-warm-muted hover:text-warm-ink border border-craft-border text-xs font-semibold transition-colors shadow-xs" type="button">Супы</button>
                <button class="px-3.5 py-1.5 rounded-lg bg-white hover:bg-paper text-warm-muted hover:text-warm-ink border border-craft-border text-xs font-semibold transition-colors shadow-xs" type="button">Птица и мясо</button>
                <button class="px-3.5 py-1.5 rounded-lg bg-white hover:bg-paper text-warm-muted hover:text-warm-ink border border-craft-border text-xs font-semibold transition-colors shadow-xs" type="button">Выпечка и тарты</button>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Card 1 -->
            <article class="bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Французский луковый суп" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['/images/популярны1.jpg']) ?>">
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-terracotta flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 45 мин</span>
                                <span>•</span>
                                <span>4 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.9
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Французский луковый суп с хрустящим багетом
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Карамелизованный в сливочном масле лук, ароматный говяжий бульон и запеченная сырная корочка грюйер.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-sage">Для терпеливых</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Card 2 -->
            <article class="bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Пряная утиная грудка" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['/images/популярный2.jpg']) ?>">
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-terracotta flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 35 мин</span>
                                <span>•</span>
                                <span>2 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.8
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Пряная утиная грудка с брусничным соусом
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Хрустящая корочка с можжевельником, нежная середина и кисло-сладкая лесная брусника с розмарином.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-warm-ink">Средняя</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Card 3 -->
            <article class="bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Лимонный тарт с меренгой" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['/images/популярный3.jpg']) ?>">
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-terracotta flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 50 мин</span>
                                <span>•</span>
                                <span>6 порций</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 5.0
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Лимонный тарт с обожженной меренгой
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Тонкое рассыпчатое песочное тесто, терпкий лимонный курд и легкие пики карамелизованной меренги.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-honey">Простая</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>
        </div>
    </section>

    <!-- ================= CULINARY NOTES & TIPS ================= -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div class="bg-paper border-2 border-craft-border rounded-3xl p-6 sm:p-8 lg:p-10 relative shadow-sm">
            <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-3">
                <div>
                    <div class="flex items-center gap-1.5 text-xs font-bold text-terracotta uppercase tracking-wider">
                        <span class="material-symbols-outlined text-base">edit_note</span> Полезные заметки
                    </div>
                    <h2 class="font-serif text-3xl md:text-4xl font-bold text-warm-ink mt-1">Секреты кулинаров</h2>
                </div>
                <p class="text-sm text-warm-muted max-w-md">Маленькие тонкости домашней кухни, которые экономят время и гарантируют идеальный вкус.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 pt-1">
                <!-- Note 1 -->
                <div class="bg-white border border-craft-border rounded-2xl p-5 shadow-xs relative flex flex-col justify-between">
                    <div class="washi-tape -top-3 left-6 w-20 h-5 rounded-xs -rotate-2 washi-terracotta"></div>
                    <div>
                        <div class="flex items-center gap-2 text-sage text-xs font-bold uppercase tracking-wider mb-2 pt-1">
                            <span class="material-symbols-outlined text-base">yard</span> Совет № 1
                        </div>
                        <h4 class="font-serif text-xl font-bold text-warm-ink">Сохранение пряных трав</h4>
                        <p class="text-sm text-warm-muted mt-2 italic leading-relaxed">
                            «Мелко нарежьте тимьян и розмарин, разложите по формочкам для льда и залейте качественным оливковым маслом. Один такой кубик зимой мгновенно наполнит суп летним ароматом».
                        </p>
                    </div>
                    <div class="pt-4 mt-3 border-t border-craft-subtle flex items-center justify-between text-xs text-warm-muted">
                        <span>Ароматные заготовки</span>
                        <span class="material-symbols-outlined text-base text-sage">check_circle</span>
                    </div>
                </div>

                <!-- Note 2 -->
                <div class="bg-white border border-craft-border rounded-2xl p-5 shadow-xs relative flex flex-col justify-between">
                    <div class="washi-tape washi-terracotta -top-3 left-6 w-20 h-5 rounded-xs rotate-1 washi-sage"></div>
                    <div>
                        <div class="flex items-center gap-2 text-terracotta text-xs font-bold uppercase tracking-wider mb-2 pt-1">
                            <span class="material-symbols-outlined text-base">straighten</span> Совет № 2
                        </div>
                        <h4 class="font-serif text-xl font-bold text-warm-ink">Пропорции без весов</h4>
                        <p class="text-sm text-warm-muted mt-2 italic leading-relaxed">
                            «Стандартную пачку сливочного масла (180 г) удобно делить ножом: пополам — 90 г, четверть — 45 г, а столовая ложка мягкого масла с горкой — ровно 20 граммов».
                        </p>
                    </div>
                    <div class="pt-4 mt-3 border-t border-craft-subtle flex items-center justify-between text-xs text-warm-muted">
                        <span>Быстрая мерка</span>
                        <span class="material-symbols-outlined text-base text-terracotta">check_circle</span>
                    </div>
                </div>

                <!-- Note 3 -->
                <div class="bg-white border border-craft-border rounded-2xl p-5 shadow-xs relative flex flex-col justify-between">
                    <div class="washi-tape washi-honey -top-3 left-6 w-20 h-5 rounded-xs -rotate-1 washi-sage"></div>
                    <div>
                        <div class="flex items-center gap-2 text-honey text-xs font-bold uppercase tracking-wider mb-2 pt-1">
                            <span class="material-symbols-outlined text-base">cookie</span> Совет № 3
                        </div>
                        <h4 class="font-serif text-xl font-bold text-warm-ink">Секрет идеального теста</h4>
                        <p class="text-sm text-warm-muted mt-2 italic leading-relaxed">
                            «Вода для песочного теста обязательно должна быть ледяной, а масло — холодным и порубленным. Не давайте маслу нагреваться руками до того, как пирог окажется в духовке».
                        </p>
                    </div>
                    <div class="pt-4 mt-3 border-t border-craft-subtle flex items-center justify-between text-xs text-warm-muted">
                        <span>Совет пекаря</span>
                        <span class="material-symbols-outlined text-base text-honey">check_circle</span>
                    </div>
                </div>
            </div>

            <!-- Banner for user contributions -->
            <div class="mt-8 bg-white border border-craft-border rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xs relative overflow-hidden">
                <div class="flex items-center gap-4">
                    <div class="w-13 h-13 rounded-2xl bg-terracotta-light text-terracotta flex items-center justify-center shrink-0 border border-terracotta/20">
                        <span class="material-symbols-outlined text-2xl">history_edu</span>
                    </div>
                    <div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink">Хотите поделиться рецептом?</h3>
                        <p class="text-sm text-warm-muted mt-0.5">Пополните архив фамильным блюдом: сохраните историю, точные граммовки и авторские заметки для поколений.</p>
                    </div>
                </div>
                <button class="shrink-0 px-6 py-3.5 bg-terracotta hover:bg-terracotta-hover text-white rounded-xl text-sm font-bold shadow-sm transition-all active:scale-95 flex items-center gap-2" id="open-add-recipe-modal-btn" type="button">
                    <span class="material-symbols-outlined text-lg leading-none">post_add</span>
                    <span>Добавить рецепт</span>
                </button>
            </div>
        </div>
    </section>
</main>




<!-- МОДАЛЬНОЕ ОКНО: ФОРМУЛЯР ПОПОЛНЕНИЯ (ЕДИНЫЙ СТИЛЬ С ГЛАВНОЙ) -->
<div aria-labelledby="modal-title" aria-modal="true" class="fixed inset-0 z-50 hidden items-start justify-center bg-[#2c221e]/60 backdrop-blur-xs p-4 overflow-y-auto py-10" id="add-recipe-modal" role="dialog">
    <div class="relative w-full max-w-[860px] bg-[#FFFDF9] border-2 border-[#D4B996] shadow-[0_20px_50px_rgba(74,53,39,0.25)] p-6 sm:p-9 text-warm-ink my-auto rounded-3xl">
        
        <!-- Верхний декор: скотч и скрепка -->
        <div class="absolute -top-4 left-1/2 -translate-x-1/2 w-36 h-7 bg-[#c8a05a]/45 border border-dashed border-[#b48c46]/50 shadow-sm transform -rotate-1 pointer-events-none flex items-center justify-center z-10"></div>
        <div class="absolute -top-5 right-14 z-20 pointer-events-none flex items-center justify-center">
            <span class="material-symbols-outlined text-warm-muted text-4xl transform rotate-45 drop-shadow-sm">attach_file</span>
        </div>
        
        <!-- Кнопка закрытия (крестик) -->
        <button aria-label="Закрыть" class="absolute top-5 right-5 w-8 h-8 bg-[#FAF4EB] border border-[#D4B996] text-warm-ink hover:bg-terracotta hover:text-white transition-colors flex items-center justify-center z-20 group rounded-lg" id="close-modal-x-btn" type="button">
            <span class="text-base font-bold leading-none font-mono">✕</span>
        </button>

        <!-- Шапка модалки -->
        <div class="border-b border-dashed border-[#D4B996] pb-6 mb-7 relative">
            <div>
                <div class="inline-flex items-center gap-2 mb-2 bg-[#F6ECE0] border border-[#D4B996] px-2.5 py-1 rounded-md">
                    <span class="material-symbols-outlined text-sm text-terracotta leading-none">menu_book</span>
                    <span class="font-mono text-[11px] font-bold tracking-wider text-warm-ink uppercase">ФОРМУЛЯР ПОПОЛНЕНИЯ КУЛИНАРНОЙ КНИГИ</span>
                </div>
                <!-- Заголовок в стиле Cormorant Garamond -->
                <h3 class="font-serif text-2xl sm:text-3xl lg:text-[32px] font-bold text-warm-ink leading-tight" id="modal-title">
                    Передать рецепт в архив
                </h3>
                <p class="text-warm-muted text-sm sm:text-base mt-1.5 max-w-xl font-sans">
                    Поделитесь секретом домашней кухни, точными граммовками и историей создания блюда для сохранения в поколениях.
                </p>
            </div>
        </div>

        <!-- Форма -->
        <form class="flex flex-col gap-7" id="add-recipe-form">
            
            <!-- Название -->
            <div class="flex flex-col gap-1.5">
                <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink flex items-center gap-1.5" for="recipe-title">
                    <span class="text-terracotta font-mono">§ 1.</span> Название блюда <span class="text-terracotta">*</span>
                </label>
                <input class="w-full bg-[#FFF9F4] border border-[#D4B996] px-3.5 py-2.5 text-warm-ink text-lg placeholder-warm-muted/50 focus:border-terracotta focus:bg-white focus:outline-none transition-colors font-serif rounded-xl" id="recipe-title" placeholder="Например: Бабушкин яблочный пирог" required="" type="text">
            </div>

            <!-- Категория -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div class="flex flex-col gap-1.5">
                    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink flex items-center gap-1.5" for="recipe-category">
                        <span class="text-terracotta font-mono">§ 2.</span> Категория блюда <span class="text-terracotta">*</span>
                    </label>
                    <div class="relative">
                        <select class="w-full bg-[#FFF9F4] border border-[#D4B996] px-3.5 py-2.5 text-sm text-warm-ink font-sans focus:border-terracotta focus:bg-white focus:outline-none transition-colors cursor-pointer appearance-none pr-9 rounded-xl" id="recipe-category" required="">
                            <option selected="" value="baking">Домашняя выпечка</option>
                            <option value="soups">Супы и бульоны</option>
                            <option value="desserts">Десерты и сладости</option>
                            <option value="mains">Основные блюда</option>
                            <option value="preserves">Заготовки и соления</option>
                            <option value="breakfast">Завтраки и перекусы</option>
                        </select>
                        <span class="material-symbols-outlined absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-warm-muted text-lg">expand_more</span>
                    </div>
                </div>
            </div>

            <!-- Технические параметры -->
            <div class="bg-[#FAF4EB] border border-[#D4B996] p-4 rounded-2xl">
                <div class="font-mono text-[11px] font-bold uppercase tracking-wider text-warm-muted mb-3 flex items-center gap-2">
                    <span class="material-symbols-outlined text-sm text-terracotta">tune</span> Технические параметры приготовления
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="flex flex-col gap-1">
                        <label class="font-mono text-[11px] uppercase tracking-wider text-warm-ink">Время готовки</label>
                        <input class="w-full bg-white border border-[#D4B996] px-3 py-1.5 text-sm font-mono font-bold text-warm-ink focus:outline-none rounded-lg" id="cooking-time" type="text" value="55 мин">
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="font-mono text-[11px] uppercase tracking-wider text-warm-ink">Сложность</label>
                        <select class="w-full bg-white border border-[#D4B996] px-3.5 py-1.5 text-sm font-sans text-warm-ink focus:outline-none rounded-lg" id="cooking-difficulty">
                            <option value="simple">Простая</option>
                            <option selected="" value="medium">Средняя</option>
                            <option value="patient">Для терпеливых</option>
                        </select>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="font-mono text-[11px] uppercase tracking-wider text-warm-ink">Выход блюда</label>
                        <input class="w-full bg-white border border-[#D4B996] px-3 py-1.5 text-sm font-mono font-bold text-warm-ink focus:outline-none rounded-lg" id="cooking-servings" type="text" value="6 порций">
                    </div>
                </div>
            </div>

            <!-- Ингредиенты -->
            <div class="flex flex-col gap-3">
                <div class="flex items-center justify-between">
                    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink">
                        <span class="text-terracotta font-mono">§ 3.</span> Раскладка ингредиентов <span class="text-terracotta">*</span>
                    </label>
                </div>
                <div class="bg-[#FAF4EB] border border-[#D4B996] p-3 sm:p-4 flex flex-col gap-2.5 rounded-2xl" id="ingredients-list-container">
                    <div class="flex items-center gap-2 bg-white border border-[#E5D2BE] p-2 shadow-xs ingredient-item rounded-xl">
                        <span class="font-mono text-xs text-warm-muted px-1 font-bold">01.</span>
                        <input class="flex-1 bg-transparent border-0 p-0 text-sm font-sans text-warm-ink focus:outline-none" placeholder="Ингредиент" type="text" value="Яблоки антоновка">
                        <div class="w-36 border-l border-[#E5D2BE] pl-2">
                            <input class="w-full bg-[#FFF9F4] border border-[#D4B996] px-2 py-1 text-xs font-mono font-bold text-right focus:outline-none rounded-md" placeholder="Количество" type="text" value="1 кг">
                        </div>
                        <button class="p-1 text-warm-muted hover:text-terracotta rounded-md" onclick="this.closest('.ingredient-item').remove()" type="button">
                            <span class="material-symbols-outlined text-base">close</span>
                        </button>
                    </div>
                </div>
                <div>
                    <button class="bg-[#FAF4EB] hover:bg-[#F2E5D4] text-warm-ink border border-[#D4B996] px-3.5 py-1.5 text-xs flex items-center gap-1.5 font-sans font-medium rounded-xl transition-colors" id="add-ingredient-button" type="button">
                        <span class="material-symbols-outlined text-sm text-terracotta">add</span>Добавить ингредиент
                    </button>
                </div>
            </div>

            <!-- Шаги приготовления -->
            <div class="flex flex-col gap-3">
                <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink">
                    <span class="text-terracotta font-mono">§ 4.</span> Пошаговое приготовление <span class="text-terracotta">*</span>
                </label>
                <div class="flex flex-col gap-3" id="steps-list-container">
                    <div class="bg-[#FAF4EB] border border-[#D4B996] p-3.5 flex flex-col gap-2.5 step-item rounded-2xl">
                        <div class="flex items-center justify-between gap-2">
                            <span class="font-mono text-xs font-bold text-terracotta uppercase step-number-label">ШАГ 1 •</span>
                            <input class="flex-1 bg-white border border-[#E5D2BE] px-2.5 py-1 text-xs font-mono font-bold text-warm-ink focus:outline-none rounded-lg" placeholder="Наименование шага" type="text" value="Песочная основа">
                            <button class="p-1 text-warm-muted hover:text-terracotta delete-step-btn rounded-md" type="button">
                                <span class="material-symbols-outlined text-base">close</span>
                            </button>
                        </div>
                        <textarea class="w-full bg-white border border-[#E5D2BE] p-2.5 text-sm text-warm-ink focus:outline-none rounded-xl font-sans" placeholder="Опишите этап..." rows="2">Холодное масло порубить с мукой...</textarea>
                    </div>
                </div>
                <div>
                    <button class="bg-[#FAF4EB] hover:bg-[#F2E5D4] text-warm-ink border border-[#D4B996] px-3.5 py-1.5 text-xs flex items-center gap-1.5 font-sans font-medium rounded-xl transition-colors" id="add-step-button" type="button">
                        <span class="material-symbols-outlined text-sm text-terracotta">add</span>Добавить шаг
                    </button>
                </div>
            </div>

            <!-- Совет хозяйки -->
            <div class="bg-[#FAF4EB] border-l-4 border-l-terracotta border border-[#D4B996] p-4 flex flex-col gap-2 rounded-2xl">
                <div class="flex items-center gap-2 text-terracotta">
                    <span class="material-symbols-outlined text-lg">lightbulb</span>
                    <label class="font-mono text-xs font-bold uppercase tracking-wider" for="recipe-secret">Особый совет или секрет хозяйки</label>
                </div>
                <textarea class="w-full bg-white border border-[#E5D2BE] p-2.5 text-sm text-warm-ink focus:outline-none rounded-xl font-serif italic" id="recipe-secret" rows="2"></textarea>
            </div>

    <!-- Photographic Upload Envelope Zone -->
<div class="flex flex-col gap-1.5">
    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink flex items-center gap-1.5">
        <span class="text-terracotta font-mono">§ 5.</span> Фотография блюда или рукописная заметка
    </label>
    <div class="border-2 border-dashed border-[#D4B996] hover:border-terracotta bg-[#FFF8F0] p-6 text-center cursor-pointer transition-colors relative group rounded-2xl" id="photo-upload-zone">
        <input accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10" id="recipe-photo-input" type="file"/>
        
        <!-- Дефолтная плашка (скрывается при выборе фото) -->
        <div class="flex flex-col items-center justify-center gap-2 pointer-events-none" id="upload-placeholder">
            <div class="w-12 h-12 bg-white border border-[#D4B996] text-terracotta flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform rounded-xl">
                <span class="material-symbols-outlined text-2xl">photo_camera</span>
            </div>
            <div class="font-bold text-base text-warm-ink font-sans">
                Перетащите снимок готового блюда или страницу фамильной тетради
            </div>
            <div class="font-mono text-[11px] text-warm-muted uppercase tracking-wider">
                ПОДДЕРЖИВАЮТСЯ ФОРМАТЫ JPG, PNG, WEBP ДО 15 МБ
            </div>
        </div>

        <!-- Контейнер для превью фото (по умолчанию скрыт) -->
        <div class="hidden flex-col items-center justify-center gap-3 relative z-20" id="image-preview-container">
            <div class="relative max-w-xs max-h-48 rounded-xl overflow-hidden border-2 border-[#D4B996] shadow-sm">
                <img alt="Превью фото" class="w-full h-full object-cover" id="image-preview-img" src="" />
            </div>
            <button class="px-3 py-1 bg-white border border-[#D4B996] text-terracotta hover:bg-terracotta hover:text-white transition-colors text-xs font-mono font-bold rounded-lg flex items-center gap-1 z-30" id="remove-photo-btn" type="button">
                <span class="material-symbols-outlined text-sm">delete</span> Удалить фото
            </button>
        </div>
    </div>
</div>

            <!-- Кнопки управления внизу формы -->
            <div class="border-t border-dashed border-[#D4B996] pt-6 flex items-center justify-end gap-3">
                <button class="px-5 py-2.5 bg-white hover:bg-paper text-warm-ink border border-[#D4B996] text-xs font-bold transition-colors rounded-xl font-sans" id="close-modal-cancel-btn" type="button">Отмена</button>
                <button class="bg-[#C85A32] hover:bg-[#B04924] text-white px-6 py-2.5 text-sm font-semibold flex items-center gap-2 transition-all rounded-xl shadow-sm font-sans" type="submit">
                    <span class="material-symbols-outlined text-base">ink_pen</span>Записать в кулинарную книгу
                </button>
            </div>
        </form>
    </div>
</div>