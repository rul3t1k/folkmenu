<?php use yii\helpers\Url; ?>
<!-- ================= MAIN CONTENT ================= -->
<main class="w-full pt-28 pb-16 flex-1">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col gap-8">

        <!-- Баннер страницы -->
        <div class="relative bg-[#FAF4EB] border-2 border-[#D4B996] p-6 sm:p-8 shadow-scrapbook rounded-3xl">
            <div class="washi-tape washi-terracotta -top-3 left-10 w-32 h-6 -rotate-2"></div>
            <div class="washi-tape washi-honey -top-2 right-12 w-24 h-5 rotate-3"></div>

            <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
                <div class="flex flex-col gap-2 max-w-2xl">
                    <div class="inline-flex items-center gap-1.5 px-3 py-1 bg-terracotta-light text-terracotta font-mono text-xs uppercase tracking-wider font-bold self-start border border-terracotta/20 rounded-md">
                        <span class="material-symbols-outlined text-sm">menu_book</span>
                        Кулинарный архив
                    </div>
                    <h1 class="text-3xl lg:text-4xl font-bold text-warm-ink font-serif">Все рецепты</h1>
                    <p class="font-sans text-xs sm:text-sm text-warm-muted leading-relaxed">
                        Выбирайте блюдо по категории, сложности и времени приготовления или найдите рецепт по названию.
                    </p>
                </div>

                <div class="bg-white px-5 py-4 border border-[#D4B996] rounded-2xl shadow-xs flex items-center gap-3 shrink-0">
                    <div class="w-10 h-10 bg-terracotta/10 text-terracotta flex items-center justify-center rounded-xl">
                        <span class="material-symbols-outlined text-2xl">restaurant_menu</span>
                    </div>
                    <div>
                        <span class="block font-mono text-[11px] text-warm-muted uppercase tracking-wider">В каталоге</span>
                        <span class="font-mono text-lg font-bold text-terracotta" id="recipes-total">12 рецептов</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Фильтры -->
        <div class="relative bg-white border border-[#D4B996] shadow-scrapbook p-6 sm:p-8 rounded-3xl">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dashed border-[#D4B996] pb-4 mb-6">
                <div>
                    <span class="font-mono text-[11px] text-warm-muted uppercase tracking-widest">Подбор блюда</span>
                    <h2 class="text-2xl text-warm-ink font-serif font-bold">Фильтры</h2>
                </div>
                <button class="px-4 py-2 bg-white hover:bg-paper text-terracotta border border-[#D4B996] font-sans text-xs font-bold transition-colors rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-auto" id="filters-reset" type="button">
                    <span class="material-symbols-outlined text-base">restart_alt</span>
                    <span>Сбросить фильтры</span>
                </button>
            </div>

            <form class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end" id="recipes-filters" onsubmit="return false">
                <div class="flex flex-col gap-1.5">
                    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="filter-search">Название</label>
                    <input autocomplete="off" class="w-full bg-[#FFF9F4] border border-[#D4B996] px-3.5 py-2.5 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="filter-search" placeholder="Например: пирог" type="text">
                </div>
                <div class="flex flex-col gap-1.5">
                    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="filter-category">Категория</label>
                    <select class="w-full bg-[#FFF9F4] border border-[#D4B996] px-3.5 py-2.5 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="filter-category"><option value="all">Все категории</option><option value="baking">Домашняя выпечка</option><option value="soups">Супы и бульоны</option><option value="desserts">Десерты и сладости</option><option value="mains">Основные блюда</option><option value="preserves">Заготовки и соления</option><option value="breakfast">Завтраки и перекусы</option></select>
                </div>
                <div class="flex flex-col gap-1.5">
                    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="filter-difficulty">Сложность</label>
                    <select class="w-full bg-[#FFF9F4] border border-[#D4B996] px-3.5 py-2.5 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="filter-difficulty"><option value="all">Любая</option><option value="simple">Простая</option><option value="medium">Средняя</option><option value="patient">Для терпеливых</option></select>
                </div>
                <div class="flex flex-col gap-1.5">
                    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="filter-time">Время</label>
                    <select class="w-full bg-[#FFF9F4] border border-[#D4B996] px-3.5 py-2.5 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="filter-time"><option value="all">Любое</option><option value="30">До 30 минут</option><option value="45">До 45 минут</option><option value="60">До 60 минут</option></select>
                </div>
                <div class="flex flex-col gap-1.5">
                    <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="filter-sort">Сортировка</label>
                    <select class="w-full bg-[#FFF9F4] border border-[#D4B996] px-3.5 py-2.5 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="filter-sort"><option value="rating">По рейтингу</option><option value="time">По времени</option><option value="title">По названию</option></select>
                </div>
            </form>
        </div>

        <!-- Результаты -->
        <div class="flex flex-col gap-6">
            <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-dashed border-[#D4B996]">
                <div>
                    <span class="font-mono text-[11px] text-warm-muted uppercase tracking-widest">Каталог</span>
                    <h2 class="text-2xl sm:text-3xl font-bold text-warm-ink font-serif" id="recipes-count">Найдено рецептов: 12</h2>
                </div>
            </div>

            <!-- Карточки-заглушки: позже будут заменены реальными данными -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="recipes-grid">
            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Французский луковый суп с хрустящим багетом" data-category="soups" data-difficulty="patient" data-time="45" data-rating="4.9">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Французский луковый суп с хрустящим багетом" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/популярны1.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Супы</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 45 мин</span>
                                <span>•</span>
                                <span>4 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.9
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Французский луковый суп с хрустящим багетом
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Карамелизованный в сливочном масле лук, ароматный говяжий бульон и запеченная сырная корочка грюйер.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-terracotta">Для терпеливых</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Пряная утиная грудка с печёными яблоками" data-category="mains" data-difficulty="medium" data-time="60" data-rating="4.8">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Пряная утиная грудка с печёными яблоками" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/популярный2.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Основное</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 60 мин</span>
                                <span>•</span>
                                <span>2 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.8
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Пряная утиная грудка с печёными яблоками
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Хрустящая кожица, сочное мясо и сладковатые яблоки с пряностями. Праздничное блюдо без лишних хлопот.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-honey">Средняя</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Лимонный тарт с воздушной меренгой" data-category="desserts" data-difficulty="patient" data-time="60" data-rating="4.9">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Лимонный тарт с воздушной меренгой" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/популярный3.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Десерты</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 60 мин</span>
                                <span>•</span>
                                <span>8 персон</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.9
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Лимонный тарт с воздушной меренгой
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Песочная корзинка, яркий лимонный курд и румяная меренга. Классика для семейного чаепития.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-terracotta">Для терпеливых</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Яблочный пирог с карамелью и корицей" data-category="baking" data-difficulty="medium" data-time="60" data-rating="4.9">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Яблочный пирог с карамелью и корицей" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/главный пирог.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Выпечка</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 60 мин</span>
                                <span>•</span>
                                <span>8 персон</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.9
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Яблочный пирог с карамелью и корицей
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Пышный пирог с ароматными яблоками, густой домашней карамелью и щепоткой корицы.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-honey">Средняя</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Быстрый яблочный пирог на сливочном масле" data-category="baking" data-difficulty="simple" data-time="45" data-rating="4.6">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Быстрый яблочный пирог на сливочном масле" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/поиск3.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Выпечка</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 45 мин</span>
                                <span>•</span>
                                <span>6 персон</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.6
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Быстрый яблочный пирог на сливочном масле
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Тающее во рту песочное тесто из муки, отборных яиц и сливочного масла.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-sage">Простая</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Деревенский картофельный гратен" data-category="mains" data-difficulty="simple" data-time="40" data-rating="4.7">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Деревенский картофельный гратен" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/поиск2.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Основное</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 40 мин</span>
                                <span>•</span>
                                <span>4 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.7
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Деревенский картофельный гратен
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Запечённый картофель с луком, чесноком и сливочным маслом под хрустящей корочкой.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-sage">Простая</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Паста Карбонара по-домашнему" data-category="mains" data-difficulty="simple" data-time="20" data-rating="4.8">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Паста Карбонара по-домашнему" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/поиск4.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Основное</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 20 мин</span>
                                <span>•</span>
                                <span>2 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.8
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Паста Карбонара по-домашнему
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Яйца, бекон, спагетти и сыр пармезан. Готовится быстрее, чем накрывается стол.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-sage">Простая</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Нежный омлет с томатами и зеленью" data-category="breakfast" data-difficulty="simple" data-time="15" data-rating="4.5">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Нежный омлет с томатами и зеленью" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/поиск1.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Завтраки</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 15 мин</span>
                                <span>•</span>
                                <span>2 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.5
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Нежный омлет с томатами и зеленью
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Пышный завтрак всего за 15 минут: свежие яйца, спелые томаты и немного сливочного масла.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-sage">Простая</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Домашний борщ с чесночными пампушками" data-category="soups" data-difficulty="patient" data-time="90" data-rating="4.9">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Домашний борщ с чесночными пампушками" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/популярны1.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Супы</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 90 мин</span>
                                <span>•</span>
                                <span>6 персон</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.9
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Домашний борщ с чесночными пампушками
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Наваристый борщ на говяжьем бульоне со свёклой, капустой и сметаной. Томится не спеша.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-terracotta">Для терпеливых</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Сырники с яблочным вареньем" data-category="breakfast" data-difficulty="simple" data-time="30" data-rating="4.7">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Сырники с яблочным вареньем" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/пирог2.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Завтраки</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 30 мин</span>
                                <span>•</span>
                                <span>3 персоны</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.7
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Сырники с яблочным вареньем
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Нежные творожные сырники с золотистой корочкой. Идеальны к воскресному завтраку.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-sage">Простая</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Яблочное варенье с корицей на зиму" data-category="preserves" data-difficulty="simple" data-time="60" data-rating="4.7">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Яблочное варенье с корицей на зиму" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/шаг1.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Заготовки</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 60 мин</span>
                                <span>•</span>
                                <span>10 персон</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.7
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Яблочное варенье с корицей на зиму
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Янтарные дольки яблок в прозрачном сиропе. Заготовка, которая согреет в холода.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-sage">Простая</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            <!-- Рецепт-заглушка -->
            <article class="recipe-card bg-white border border-craft-border rounded-2xl p-4 shadow-sm hover:shadow-card-lift transition-all duration-300 flex flex-col justify-between group" data-title="Сдобные булочки с корицей" data-category="baking" data-difficulty="medium" data-time="55" data-rating="4.5">
                <div>
                    <div class="relative w-full h-56 rounded-xl overflow-hidden bg-paper border border-craft-subtle">
                        <img alt="Сдобные булочки с корицей" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?= Url::to(['images/шаг4.jpg']) ?>">
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 text-warm-ink text-[11px] font-bold shadow-xs">Выпечка</span>
                        <button aria-label="Нравится" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-warm-muted flex items-center justify-center shadow-xs transition-transform active:scale-90" type="button">
                            <span class="material-symbols-outlined text-lg">favorite_border</span>
                        </button>
                    </div>
                    <div class="pt-4">
                        <div class="flex items-center justify-between text-xs text-warm-muted mb-2">
                            <div class="flex items-center gap-2">
                                <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> 55 мин</span>
                                <span>•</span>
                                <span>8 персон</span>
                            </div>
                            <div class="flex items-center gap-1 font-bold text-terracotta">
                                <span class="material-symbols-outlined text-sm leading-none fill-1">star</span> 4.5
                            </div>
                        </div>
                        <h3 class="font-serif text-2xl font-bold text-warm-ink leading-snug group-hover:text-terracotta transition-colors line-clamp-2">
                            Сдобные булочки с корицей
                        </h3>
                        <p class="text-sm text-warm-muted mt-2 line-clamp-2 leading-relaxed">
                            Мягкое дрожжевое тесто, сливочная начинка и сахарная глазурь. Аромат на весь дом.
                        </p>
                    </div>
                </div>
                <div class="pt-4 mt-4 border-t border-craft-subtle flex items-center justify-between">
                    <div class="text-xs">
                        <span class="text-warm-muted block">Сложность:</span>
                        <span class="font-semibold text-honey">Средняя</span>
                    </div>
                    <a class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5" href="<?= Url::to(['recipe']) ?>">
                        <span>Открыть рецепт</span>
                        <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
            </article>

            </div>

            <div class="hidden relative text-center bg-white border-2 border-dashed border-[#D4B996] rounded-3xl p-8 shadow-scrapbook" id="recipes-empty">
                <span class="material-symbols-outlined text-4xl text-terracotta">search_off</span>
                <h3 class="font-serif text-2xl font-bold text-warm-ink mt-2">Ничего не найдено</h3>
                <p class="font-sans text-sm text-warm-muted mt-1">Попробуйте изменить фильтры или сбросить их.</p>
                <button class="mt-6 px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white font-sans text-xs font-bold transition-colors rounded-xl shadow-xs inline-flex items-center gap-1.5 cursor-pointer" id="empty-reset" type="button">
                    <span class="material-symbols-outlined text-base">restart_alt</span>
                    <span>Сбросить фильтры</span>
                </button>
            </div>
        </div>

    </div>
</main>