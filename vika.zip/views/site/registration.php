<?php use yii\helpers\Url; ?>
<!-- ================= MAIN CONTENT: AUTH PAGE ================= -->
<main class="w-full pt-24 pb-12 flex-1">
    <div class="w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        
        <!-- Auth Card Container -->
        <div class="relative max-w-md mx-auto my-6 bg-surface border-2 border-[#dec0b7] shadow-scrapbook p-8 sm:p-10 rounded-3xl">
            
            <!-- Vintage Accents: Tape & Paperclip -->
            <div class="washi-tape washi-honey -top-4 left-1/2 -translate-x-1/2 w-32 h-6 -rotate-1 pointer-events-none rounded-xs"></div>
            <div class="absolute -top-5 right-10 z-20 pointer-events-none flex items-center justify-center">
                <span class="material-symbols-outlined text-warm-muted text-3xl transform rotate-45 drop-shadow-xs">attach_file</span>
            </div>

            <!-- Tab Switches -->
            <div class="flex border-b border-[#dec0b7] mb-8">
                <a class="flex-1 pb-3 text-center font-serif text-xl font-medium text-warm-muted hover:text-warm-ink border-b-2 border-transparent transition-all duration-200 cursor-pointer" href="<?= Url::to(['login']) ?>">Вход</a>
                <a class="flex-1 pb-3 text-center font-serif text-xl font-bold text-terracotta border-b-2 border-terracotta transition-all duration-200 cursor-pointer" href="<?= Url::to(['registration']) ?>">Регистрация</a>
            </div>

            <!-- Register Section -->
            <div id="auth-register-section">
                <div class="mb-6 text-center">
                    <h2 class="font-serif text-2xl sm:text-3xl font-bold text-warm-ink mb-1.5">Регистрация в архиве</h2>
                    <p class="font-sans text-xs text-warm-muted">Создайте аккаунт для сохранения рецептов и списка покупок</p>
                </div>
                <form class="flex flex-col gap-4" id="register-form">
                    <div class="flex flex-col gap-1.5">
                        <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="reg-name">ФИО</label>
                        <input class="w-full bg-[#FFF9F4] border border-[#dec0b7] p-3 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="reg-name" placeholder="Васильева Анна Сергеевна" required="" autocomplete="name" type="text">
                    </div>
                    <div class="flex flex-col gap-1.5">
                        <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="reg-username">Логин</label>
                        <input class="w-full bg-[#FFF9F4] border border-[#dec0b7] p-3 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="reg-username" placeholder="Придумайте логин" required="" autocomplete="username" type="text">
                    </div>
                    <div class="flex flex-col gap-1.5">
                        <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="reg-password-input">Пароль</label>
                        <div class="relative flex items-center">
                            <input class="w-full bg-[#FFF9F4] border border-[#dec0b7] p-3 pr-10 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="reg-password-input" placeholder="Минимум 8 символов" minlength="8" autocomplete="new-password" required="" type="password">
                            <button class="absolute right-3 text-warm-muted hover:text-warm-ink p-1 cursor-pointer flex items-center toggle-pass-btn" data-target="reg-password-input" type="button">
                                <span class="material-symbols-outlined text-lg leading-none">visibility</span>
                            </button>
                        </div>
                    </div>
                    <div class="flex flex-col gap-1.5">
                        <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="reg-email-input">Электронная почта</label>
                        <input class="w-full bg-[#FFF9F4] border border-[#dec0b7] p-3 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="reg-email-input" placeholder="name@example.com" required="" autocomplete="email" type="email">
                    </div>
                    <div class="flex flex-col gap-1.5">
                        <label class="font-mono text-xs font-bold uppercase tracking-wider text-warm-ink" for="reg-phone">Номер телефона</label>
                        <input class="w-full bg-[#FFF9F4] border border-[#dec0b7] p-3 text-sm text-warm-ink placeholder-[#8a726a] outline-none focus:border-terracotta font-sans rounded-xl transition-colors" id="reg-phone" placeholder="+7 (999) 123-45-67" required="" autocomplete="tel" type="tel">
                    </div>
                    <div class="flex items-start gap-2.5 pt-1">
                        <input checked="" class="w-4 h-4 mt-0.5 text-[#C85A32] !bg-[#C85A32] border-[#dec0b7] rounded-md cursor-pointer focus:ring-[#C85A32] accent-[#C85A32]" id="reg-agree" required="" type="checkbox">
                        <label class="font-sans text-xs text-warm-muted cursor-pointer select-none" for="reg-agree">Согласен с правилами кулинарного архива</label>
                    </div>
                    <button class="w-full mt-2 py-3.5 px-6 bg-terracotta hover:bg-terracotta-hover text-white font-sans text-xs font-bold uppercase tracking-wider shadow-sm hover:shadow-md transition-all rounded-xl cursor-pointer flex items-center justify-center gap-2" type="submit">
                        <span>Зарегистрироваться</span>
                    </button>
                </form>
                <div class="mt-6 text-center text-xs font-sans text-warm-muted">
                    Уже зарегистрированы? <a class="text-terracotta font-bold hover:underline cursor-pointer" href="<?= Url::to(['login']) ?>">Войти</a>
                </div>
            </div>
            
        </div>
    </div>
</main>

<!-- Toast Notification Box -->
<div class="fixed bottom-6 right-6 z-50 bg-[#FAF4EB] border-2 border-terracotta shadow-scrapbook p-4 max-w-sm hidden rounded-2xl" id="auth-toast">
    <div class="flex items-start gap-3">
        <span class="material-symbols-outlined text-terracotta text-2xl shrink-0">verified</span>
        <div class="flex flex-col">
            <span class="font-serif font-bold text-base text-warm-ink" id="toast-title">Folk Menu</span>
            <span class="font-sans text-xs text-warm-muted mt-0.5" id="toast-message">Уведомление</span>
        </div>
    </div>
</div>
