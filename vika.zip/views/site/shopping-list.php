<?php
use yii\helpers\Url;
?>
<!-- ================= MAIN CONTENT ================= -->
<main class="w-full pt-28 pb-16 flex-1">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Header Title Banner -->
        <div class="relative mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
                <div class="inline-flex items-center gap-1.5 px-3 py-1 bg-[#EDF4EF] text-sage font-mono text-xs tracking-wider uppercase shadow-xs -rotate-1 mb-2 border border-sage/20 rounded-md">
                    <span class="material-symbols-outlined text-sm">shopping_basket</span>
                    Кладовая и припасы
                </div>
                <h1 class="text-3xl sm:text-4xl font-bold text-warm-ink font-serif">Список покупок</h1>
                <p class="font-sans text-xs sm:text-sm text-warm-muted max-w-xl mt-1.5">
                    Сводный перечень продуктов из ваших рецептов. Отмечайте купленное в магазине или добавляйте свои продукты.
                </p>
            </div>

            <!-- Header Counter Ticket -->
            <div class="relative bg-[#FFF9F4] px-4 py-3 rounded-2xl shadow-xs border-2 border-dashed border-[#D4B996] flex items-center gap-3 shrink-0">
                <div class="w-10 h-10 bg-terracotta/10 flex items-center justify-center text-terracotta rounded-xl">
                    <span class="material-symbols-outlined text-2xl">receipt_long</span>
                </div>
                <div>
                    <span class="block font-mono text-[11px] text-warm-muted uppercase tracking-wider">Всего в списке</span>
                    <span class="font-mono text-lg font-bold text-terracotta" id="header-counter">6 позиций</span>
                </div>
            </div>
        </div>

        <!-- Notepad Container -->
        <div class="relative bg-white rounded-3xl shadow-scrapbook p-6 sm:p-8 border border-[#D4B996]">
            
            <!-- Washi Tapes Decor -->
            <div class="washi-tape washi-sage -top-3 left-10 w-32 h-6 -rotate-2"></div>
            <div class="washi-tape washi-honey -top-2 right-12 w-24 h-5 rotate-3"></div>

            <!-- Notepad Binding Simulation -->
            <div class="flex justify-between items-center pb-4 border-b-2 border-dashed border-[#D4B996] mb-6">
                <div class="flex items-center gap-3">
                    <span class="w-3.5 h-3.5 rounded-full bg-[#FAF4EB] border border-[#D4B996] shadow-inner inline-block"></span>
                    <span class="w-3.5 h-3.5 rounded-full bg-[#FAF4EB] border border-[#D4B996] shadow-inner inline-block"></span>
                    <span class="w-3.5 h-3.5 rounded-full bg-[#FAF4EB] border border-[#D4B996] shadow-inner inline-block"></span>
                    <span class="w-3.5 h-3.5 rounded-full bg-[#FAF4EB] border border-[#D4B996] shadow-inner inline-block"></span>
                </div>
                <span class="font-mono text-xs text-warm-muted uppercase font-bold tracking-wider">Ревизия припасов</span>
            </div>

            <!-- Add Custom Item Form -->
            <form class="mb-6 relative flex items-center" id="add-item-form">
                <div class="w-full flex items-stretch border border-[#D4B996] bg-[#FFF9F4] shadow-xs focus-within:border-terracotta rounded-xl overflow-hidden">
                    <input autocomplete="off" class="w-full bg-transparent font-sans text-xs sm:text-sm text-warm-ink placeholder-[#8a726a] px-4 py-3 border-0 focus:ring-0 outline-none" id="new-item-input" placeholder="Вписать свой ингредиент (например, Стручковая ваниль)..." type="text">
                    <button aria-label="Добавить ингредиент" class="shrink-0 px-5 bg-terracotta hover:bg-terracotta-hover text-white font-sans text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer" type="submit">
                        <span class="material-symbols-outlined text-base">add</span>
                        <span>Добавить</span>
                    </button>
                </div>
            </form>

            <!-- Unified Ingredients List Container -->
            <div class="space-y-2 mb-6" id="shopping-list-container">
                
                <!-- Item 1 -->
                <div class="item-row group flex items-center justify-between p-3 bg-[#FFF9F4] hover:bg-[#FAF4EB] transition-colors border border-[#D4B996]/50 rounded-xl" data-checked="true">
                    <div class="flex items-center gap-3 min-w-0">
                        <input checked="" class="custom-checkbox toggle-check" type="checkbox">
                        <div class="min-w-0">
                            <p class="item-title font-sans text-sm text-warm-ink line-through opacity-60 font-medium truncate">Яблоки антоновские (кисло-сладкие)</p>
                            <span class="font-mono text-[11px] text-warm-muted block truncate">для «Яблочного песочного пирога»</span>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 shrink-0">
                        <div class="flex items-center gap-1 bg-white border border-[#D4B996] rounded-lg px-1 py-0.5 shadow-xs">
                            <button class="qty-btn-minus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">−</button>
                            <input class="qty-val w-10 text-center font-mono text-xs font-bold text-terracotta bg-transparent border-0 focus:ring-0 p-0" min="1" max="99" type="number" value="4">
                            <button class="qty-btn-plus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">+</button>
                        </div>
                        <button class="delete-item text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить" type="button">
                            <span class="material-symbols-outlined text-lg leading-none">close</span>
                        </button>
                    </div>
                </div>

                <!-- Item 2 -->
                <div class="item-row group flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] transition-colors border border-[#D4B996]/50 rounded-xl" data-checked="false">
                    <div class="flex items-center gap-3 min-w-0">
                        <input class="custom-checkbox toggle-check" type="checkbox">
                        <div class="min-w-0">
                            <p class="item-title font-sans text-sm text-warm-ink font-medium truncate">Мука пшеничная высшего сорта — 250 г</p>
                            <span class="font-mono text-[11px] text-warm-muted block truncate">для «Яблочного песочного пирога»</span>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 shrink-0">
                        <div class="flex items-center gap-1 bg-[#FFF9F4] border border-[#D4B996] rounded-lg px-1 py-0.5 shadow-xs">
                            <button class="qty-btn-minus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">−</button>
                            <input class="qty-val w-10 text-center font-mono text-xs font-bold text-terracotta bg-transparent border-0 focus:ring-0 p-0" min="1" max="99" type="number" value="1">
                            <button class="qty-btn-plus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">+</button>
                        </div>
                        <button class="delete-item text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить" type="button">
                            <span class="material-symbols-outlined text-lg leading-none">close</span>
                        </button>
                    </div>
                </div>

                <!-- Item 3 -->
                <div class="item-row group flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] transition-colors border border-[#D4B996]/50 rounded-xl" data-checked="false">
                    <div class="flex items-center gap-3 min-w-0">
                        <input class="custom-checkbox toggle-check" type="checkbox">
                        <div class="min-w-0">
                            <p class="item-title font-sans text-sm text-warm-ink font-medium truncate">Сливочное масло 82.5% — 150 г</p>
                            <span class="font-mono text-[11px] text-warm-muted block truncate">для «Яблочного песочного пирога»</span>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 shrink-0">
                        <div class="flex items-center gap-1 bg-[#FFF9F4] border border-[#D4B996] rounded-lg px-1 py-0.5 shadow-xs">
                            <button class="qty-btn-minus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">−</button>
                            <input class="qty-val w-10 text-center font-mono text-xs font-bold text-terracotta bg-transparent border-0 focus:ring-0 p-0" min="1" max="99" type="number" value="1">
                            <button class="qty-btn-plus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">+</button>
                        </div>
                        <button class="delete-item text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить" type="button">
                            <span class="material-symbols-outlined text-lg leading-none">close</span>
                        </button>
                    </div>
                </div>

                <!-- Item 4 -->
                <div class="item-row group flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] transition-colors border border-[#D4B996]/50 rounded-xl" data-checked="false">
                    <div class="flex items-center gap-3 min-w-0">
                        <input class="custom-checkbox toggle-check" type="checkbox">
                        <div class="min-w-0">
                            <p class="item-title font-sans text-sm text-warm-ink font-medium truncate">Сахар тростниковый для карамели — 120 г</p>
                            <span class="font-mono text-[11px] text-warm-muted block truncate">для «Яблочного песочного пирога»</span>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 shrink-0">
                        <div class="flex items-center gap-1 bg-[#FFF9F4] border border-[#D4B996] rounded-lg px-1 py-0.5 shadow-xs">
                            <button class="qty-btn-minus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">−</button>
                            <input class="qty-val w-10 text-center font-mono text-xs font-bold text-terracotta bg-transparent border-0 focus:ring-0 p-0" min="1" max="99" type="number" value="1">
                            <button class="qty-btn-plus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">+</button>
                        </div>
                        <button class="delete-item text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить" type="button">
                            <span class="material-symbols-outlined text-lg leading-none">close</span>
                        </button>
                    </div>
                </div>

                <!-- Item 5 -->
                <div class="item-row group flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] transition-colors border border-[#D4B996]/50 rounded-xl" data-checked="false">
                    <div class="flex items-center gap-3 min-w-0">
                        <input class="custom-checkbox toggle-check" type="checkbox">
                        <div class="min-w-0">
                            <p class="item-title font-sans text-sm text-warm-ink font-medium truncate">Яйца куриные C0 — 2 шт.</p>
                            <span class="font-mono text-[11px] text-warm-muted block truncate">для «Яблочного песочного пирога»</span>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 shrink-0">
                        <div class="flex items-center gap-1 bg-[#FFF9F4] border border-[#D4B996] rounded-lg px-1 py-0.5 shadow-xs">
                            <button class="qty-btn-minus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">−</button>
                            <input class="qty-val w-10 text-center font-mono text-xs font-bold text-terracotta bg-transparent border-0 focus:ring-0 p-0" min="1" max="99" type="number" value="1">
                            <button class="qty-btn-plus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">+</button>
                        </div>
                        <button class="delete-item text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить" type="button">
                            <span class="material-symbols-outlined text-lg leading-none">close</span>
                        </button>
                    </div>
                </div>

                <!-- Item 6 -->
                <div class="item-row group flex items-center justify-between p-3 bg-white hover:bg-[#FFF9F4] transition-colors border border-[#D4B996]/50 rounded-xl" data-checked="false">
                    <div class="flex items-center gap-3 min-w-0">
                        <input class="custom-checkbox toggle-check" type="checkbox">
                        <div class="min-w-0">
                            <p class="item-title font-sans text-sm text-warm-ink font-medium truncate">Корица цейлонская молотая — 1 ч. л.</p>
                            <span class="font-mono text-[11px] text-warm-muted block truncate">для «Яблочного песочного пирога»</span>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 shrink-0">
                        <div class="flex items-center gap-1 bg-[#FFF9F4] border border-[#D4B996] rounded-lg px-1 py-0.5 shadow-xs">
                            <button class="qty-btn-minus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">−</button>
                            <input class="qty-val w-10 text-center font-mono text-xs font-bold text-terracotta bg-transparent border-0 focus:ring-0 p-0" min="1" max="99" type="number" value="1">
                            <button class="qty-btn-plus text-xs text-warm-ink hover:text-terracotta px-1.5 font-bold transition-colors select-none" type="button">+</button>
                        </div>
                        <button class="delete-item text-warm-muted hover:text-terracotta p-1 transition-colors cursor-pointer" title="Удалить" type="button">
                            <span class="material-symbols-outlined text-lg leading-none">close</span>
                        </button>
                    </div>
                </div>

            </div>

            <!-- Summary Footer Bar -->
            <div class="pt-4 border-t-2 border-dashed border-[#D4B996] flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#FFF9F4] p-4 rounded-2xl">
                <div class="flex items-center gap-2 font-mono text-xs text-warm-muted">
                    <span class="material-symbols-outlined text-sage text-base">checklist_rtl</span>
                    <span class="font-bold" id="summary-text">Всего: 6 • Куплено: 1 • Осталось: 5</span>
                </div>
                <div class="flex items-center gap-2">
                    <button class="px-4 py-2 bg-terracotta hover:bg-terracotta-hover text-white font-sans text-xs font-bold transition-colors rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer" id="clear-bought" type="button">
                        <span class="material-symbols-outlined text-sm">delete</span>
                        <span>Убрать купленное</span>
                    </button>
                    <!-- <button class="px-3 py-2 bg-white border border-[#D4B996] hover:bg-paper text-warm-ink font-sans text-xs font-medium transition-colors rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer" onclick="window.print()" title="Распечатать" type="button">
                        <span class="material-symbols-outlined text-sm text-terracotta">print</span>
                        <span>Печать</span>
                    </button>
                    <button class="px-3 py-2 bg-white border border-[#D4B996] hover:bg-paper text-warm-ink font-sans text-xs font-medium transition-colors rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer" id="share-btn" title="Отправить" type="button">
                        <span class="material-symbols-outlined text-sm text-terracotta">share</span>
                        <span>Поделиться</span>
                    </button> -->
                </div>
            </div>

        </div>

    </div>
</main>

<!-- Delete Confirmation Modal (Адаптировано под единый крафтовый стиль) -->
<div aria-labelledby="modal-title" aria-modal="true" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-warm-ink/60 backdrop-blur-xs transition-opacity duration-200 opacity-0 pointer-events-none" id="delete-modal" role="dialog">
    <div class="relative w-full max-w-md bg-white rounded-3xl shadow-scrapbook border-2 border-dashed border-[#D4B996] p-6 sm:p-7 transform transition-transform duration-200 scale-95" id="delete-modal-panel">
        <div class="washi-tape washi-sage -top-3.5 left-1/2 -translate-x-1/2 w-28 h-6 -rotate-1 pointer-events-none"></div>
        
        <div class="flex items-start justify-between mb-4 pt-1">
            <div class="flex items-center gap-2">
                <span class="material-symbols-outlined text-terracotta text-lg">bookmark</span>
                <span class="font-mono text-xs font-bold text-terracotta uppercase tracking-wider">Ревизия припасов</span>
            </div>
            <button aria-label="Закрыть окно" class="text-warm-muted hover:text-warm-ink transition-colors p-1 cursor-pointer" id="cancel-delete-x" type="button">
                <span class="material-symbols-outlined text-lg leading-none">close</span>
            </button>
        </div>

        <h3 class="text-2xl font-serif font-bold text-warm-ink mb-3" id="modal-title">
            Удалить позицию из списка?
        </h3>

        <div class="bg-[#FFF9F4] border-l-4 border-l-terracotta border border-[#D4B996] p-3.5 mb-4 rounded-xl shadow-xs">
            <span class="block font-mono text-[10px] text-warm-muted uppercase tracking-wider mb-1">Выбранная позиция:</span>
            <p class="font-sans text-sm font-bold text-warm-ink" id="modal-item-name">«Яблоки антоновские»</p>
        </div>

        <p class="font-sans text-xs text-warm-muted leading-relaxed mb-6">
            Вы всегда сможете добавить её снова вручную или из карточки рецепта.
        </p>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-dashed border-[#D4B996]">
            <button class="px-4 py-2 border border-[#D4B996] bg-white hover:bg-paper text-warm-ink font-sans text-xs font-bold transition-colors rounded-xl cursor-pointer" id="cancel-delete-btn" type="button">
                Отмена
            </button>
            <button class="px-5 py-2 bg-terracotta hover:bg-terracotta-hover text-white font-sans text-xs font-bold transition-colors rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer" id="confirm-delete-btn" type="button">
                <span class="material-symbols-outlined text-sm">delete</span>
                <span>Удалить</span>
            </button>
        </div>
    </div>
</div>

<!-- Toast Notification Box -->
<div class="fixed bottom-6 right-6 z-50 bg-[#FAF4EB] border-2 border-terracotta shadow-scrapbook p-4 max-w-sm hidden rounded-2xl" id="auth-toast">
    <div class="flex items-start gap-3">
        <span class="material-symbols-outlined text-terracotta text-2xl shrink-0">verified</span>
        <div class="flex flex-col">
            <span class="font-serif font-bold text-base text-warm-ink" id="toast-title">Folk Menu</span>
            <span class="font-sans text-xs text-warm-muted mt-0.5" id="toast-message">Уведомление</span>
        </div>
    </div>
</div>

