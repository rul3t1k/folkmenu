<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\helpers\FileHelper;
use yii\validators\FileValidator;
use yii\web\UploadedFile;

/**
 * Создание / редактирование рецепта вместе с ингредиентами, шагами и фото.
 * Работает с таблицами recipe, ingredient, recipe_ingredient, recipe_step.
 */
class RecipeForm extends Model
{
    const STATUS_DRAFT = 'Черновик';
    const STATUS_PUBLISHED = 'Опубликовано';
    const DIFFICULTIES = ['Простая', 'Средняя', 'Для терпеливых'];
    const UPLOAD_DIR = 'uploads/recipes';

    public $title;
    public $category_id;
    public $description;
    public $difficulty = 'Средняя';
    public $prep_time_min;
    public $cook_time_min;
    public $equipment;
    public $calories;
    public $protein;
    public $fat;
    public $carbs;
    public $secret;
    public $status;          // "draft" | "publish"
    public $remove_photo;
    public $ingredients = [];
    public $steps = [];

    /** @var Recipe */
    private $_recipe;
    private $_userId;
    private $_messages = [];

    public function __construct(Recipe $recipe, $userId, $config = [])
    {
        $this->_recipe = $recipe;
        $this->_userId = $userId;
        parent::__construct($config);
    }

    public function rules()
    {
        return [
            [['title', 'description', 'equipment', 'secret'], 'trim'],
            [['title'], 'required', 'message' => 'Укажите название блюда'],
            ['title', 'string', 'max' => 200, 'tooLong' => 'Название не длиннее 200 символов'],
            ['category_id', 'required', 'message' => 'Выберите категорию'],
            ['category_id', 'exist', 'targetClass' => Category::class, 'targetAttribute' => 'id', 'message' => 'Такой категории нет'],
            ['difficulty', 'in', 'range' => self::DIFFICULTIES, 'message' => 'Неверная сложность'],
            [['prep_time_min', 'cook_time_min', 'calories'], 'default', 'value' => null],
            [['prep_time_min', 'cook_time_min', 'calories'], 'integer', 'min' => 0, 'max' => 100000, 'message' => 'Время и калории — целые числа', 'tooSmall' => 'Значение не может быть отрицательным'],
            [['protein', 'fat', 'carbs'], 'filter', 'filter' => function ($v) { return is_string($v) ? str_replace(',', '.', $v) : $v; }],
            [['protein', 'fat', 'carbs'], 'default', 'value' => null],
            [['protein', 'fat', 'carbs'], 'number', 'min' => 0, 'max' => 9999.9, 'message' => 'Белки, жиры и углеводы — числа', 'tooSmall' => 'Значение не может быть отрицательным'],
            ['equipment', 'string', 'max' => 255, 'tooLong' => 'Оборудование — не длиннее 255 символов'],
            [['description', 'secret'], 'string'],
            ['status', 'in', 'range' => ['draft', 'publish']],
            ['remove_photo', 'boolean'],
            [['ingredients', 'steps'], 'safe'],
        ];
    }

    /** Пересобираем сообщения об ошибках в один плоский список. */
    public function getErrorMessages()
    {
        $out = $this->_messages;
        foreach ($this->getFirstErrors() as $e) {
            $out[] = $e;
        }
        return array_values(array_unique($out));
    }

    private function cleanIngredients()
    {
        $rows = [];
        $seen = [];
        $n = 0;
        foreach ((array)$this->ingredients as $row) {
            $name = trim(preg_replace('/\s+/u', ' ', (string)($row['name'] ?? '')));
            $qty = trim(str_replace(',', '.', (string)($row['quantity'] ?? '')));
            $unit = trim((string)($row['unit'] ?? ''));
            if ($name === '' && $qty === '' && $unit === '') {
                continue;
            }
            $n++;
            if ($name === '') {
                $this->_messages[] = "Ингредиент №$n: укажите название";
                continue;
            }
            if (mb_strlen($name) > 255) {
                $this->_messages[] = "Ингредиент №$n: слишком длинное название";
                continue;
            }
            if ($qty !== '' && (!is_numeric($qty) || (float)$qty < 0 || (float)$qty > 99999999)) {
                $this->_messages[] = "Ингредиент «{$name}»: количество должно быть числом";
                continue;
            }
            if (mb_strlen($unit) > 255) {
                $this->_messages[] = "Ингредиент «{$name}»: слишком длинная единица измерения";
                continue;
            }
            $key = mb_strtolower($name);
            if (isset($seen[$key])) {
                $this->_messages[] = "Ингредиент «{$name}» указан дважды";
                continue;
            }
            $seen[$key] = true;
            $rows[] = ['name' => $name, 'quantity' => $qty === '' ? null : (float)$qty, 'unit' => $unit === '' ? null : $unit];
        }
        return $rows;
    }

    private function cleanSteps()
    {
        $rows = [];
        $n = 0;
        foreach ((array)$this->steps as $row) {
            $title = trim((string)($row['title'] ?? ''));
            $desc = trim((string)($row['description'] ?? ''));
            $dur = trim((string)($row['duration_min'] ?? ''));
            if ($title === '' && $desc === '' && $dur === '') {
                continue;
            }
            $n++;
            if ($desc === '') {
                $this->_messages[] = "Шаг №$n: опишите этап";
                continue;
            }
            if (mb_strlen($title) > 255) {
                $this->_messages[] = "Шаг №$n: слишком длинное название";
                continue;
            }
            if ($dur !== '' && (!ctype_digit($dur) || (int)$dur > 100000)) {
                $this->_messages[] = "Шаг №$n: длительность — целое число минут";
                continue;
            }
            $rows[] = ['title' => $title === '' ? null : $title, 'description' => $desc, 'duration_min' => $dur === '' ? null : (int)$dur];
        }
        return $rows;
    }

    public function save()
    {
        $this->_messages = [];
        $ok = $this->validate();
        $ingredients = $this->cleanIngredients();
        $steps = $this->cleanSteps();
        $publish = $this->status === 'publish';

        if ($publish && !$this->_messages && $ok) {
            if (!$ingredients) {
                $this->_messages[] = 'Для публикации добавьте хотя бы один ингредиент';
            }
            if (!$steps) {
                $this->_messages[] = 'Для публикации добавьте хотя бы один шаг приготовления';
            }
        }

        // фото
        $file = UploadedFile::getInstanceByName('photo');
        if ($file !== null && $file->error !== UPLOAD_ERR_NO_FILE) {
            $validator = new FileValidator([
                'extensions' => ['jpg', 'jpeg', 'png', 'webp', 'gif'],
                'checkExtensionByMimeType' => true,
                'maxSize' => 15 * 1024 * 1024,
                'tooBig' => 'Фото больше 15 МБ',
                'wrongExtension' => 'Фото: допустимы JPG, PNG, WEBP, GIF',
                'uploadRequired' => 'Не удалось загрузить фото',
            ]);
            $error = null;
            if (!$validator->validate($file, $error)) {
                $this->_messages[] = $error;
            }
        } else {
            $file = null;
        }

        if (!$ok || $this->_messages) {
            return false;
        }

        $recipe = $this->_recipe;
        $isNew = $recipe->isNewRecord;
        $oldPhoto = $recipe->photo;
        $now = date('Y-m-d H:i:s');

        $recipe->user_id = $this->_userId;
        $recipe->title = $this->title;
        $recipe->category_id = (int)$this->category_id;
        $recipe->description = $this->description === '' ? null : $this->description;
        $recipe->difficulty = $this->difficulty;
        $recipe->prep_time_min = $this->prep_time_min;
        $recipe->cook_time_min = $this->cook_time_min;
        $recipe->equipment = $this->equipment === '' ? null : $this->equipment;
        $recipe->secret = $this->secret === '' ? null : $this->secret;
        $recipe->calories = $this->calories;
        $recipe->protein = $this->protein;
        $recipe->fat = $this->fat;
        $recipe->carbs = $this->carbs;
        $recipe->status = $publish ? self::STATUS_PUBLISHED : self::STATUS_DRAFT;
        $recipe->updated_at = $now;
        if ($isNew) {
            $recipe->created_at = $now;
        }

        $newPhoto = null;
        if ($file !== null) {
            $dir = Yii::getAlias('@webroot') . '/' . self::UPLOAD_DIR;
            FileHelper::createDirectory($dir);
            $name = Yii::$app->security->generateRandomString(16) . '.' . strtolower($file->extension);
            if (!$file->saveAs($dir . '/' . $name)) {
                $this->_messages[] = 'Не удалось сохранить фото на сервере';
                return false;
            }
            $newPhoto = self::UPLOAD_DIR . '/' . $name;
            $recipe->photo = $newPhoto;
        } elseif ($this->remove_photo) {
            $recipe->photo = null;
        }

        $tx = Yii::$app->db->beginTransaction();
        try {
            if (!$recipe->save()) {
                throw new \RuntimeException(implode('; ', $recipe->getFirstErrors()));
            }

            RecipeIngredient::deleteAll(['recipe_id' => $recipe->id]);
            RecipeStep::deleteAll(['recipe_id' => $recipe->id]);

            foreach ($ingredients as $pos => $row) {
                // найти по названию (без учёта регистра) или создать
                $ing = Ingredient::find()->where(['name' => $row['name']])->one();
                if ($ing === null) {
                    $ing = new Ingredient(['name' => $row['name']]);
                    if (!$ing->save()) {
                        throw new \RuntimeException(implode('; ', $ing->getFirstErrors()));
                    }
                }
                $ri = new RecipeIngredient([
                    'recipe_id' => $recipe->id,
                    'ingredient_id' => $ing->id,
                    'quantity' => $row['quantity'],
                    'unit' => $row['unit'],
                    'position' => $pos + 1,
                ]);
                if (!$ri->save()) {
                    throw new \RuntimeException(implode('; ', $ri->getFirstErrors()));
                }
            }

            foreach ($steps as $i => $row) {
                $st = new RecipeStep([
                    'recipe_id' => $recipe->id,
                    'step_number' => $i + 1,
                    'title' => $row['title'],
                    'description' => $row['description'],
                    'duration_min' => $row['duration_min'],
                ]);
                if (!$st->save()) {
                    throw new \RuntimeException(implode('; ', $st->getFirstErrors()));
                }
            }

            $tx->commit();
        } catch (\Throwable $e) {
            $tx->rollBack();
            if ($newPhoto) {
                @unlink(Yii::getAlias('@webroot') . '/' . $newPhoto);
            }
            Yii::error($e->getMessage(), __METHOD__);
            $this->_messages[] = 'Не удалось сохранить рецепт: ' . $e->getMessage();
            return false;
        }

        // старый загруженный файл больше не нужен
        if ($oldPhoto && $oldPhoto !== $recipe->photo && strpos($oldPhoto, self::UPLOAD_DIR . '/') === 0) {
            @unlink(Yii::getAlias('@webroot') . '/' . $oldPhoto);
        }
        return true;
    }
}
